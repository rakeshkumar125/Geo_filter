<?php
if(file_exists("connection.php"))
{
  include("connection.php");
}
$page_to_hit = "browse_retailers_details.php";

class urlparser_vendors
{
	public static function parseurl($segments)
	{
       global $base_url;  
       //print_r($segments);exit;
       // echo "select * from vendors_profile where alias='$segments[1]'";
       $retailer_rs        = mysqli_query($GLOBALS["___mysqli_ston"], "select * from vendors_profile where alias='$segments[1]'") or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
       $retailer_row       = mysqli_fetch_array($retailer_rs);



       if(!mysqli_num_rows($retailer_rs))
        { 
          $old_url =  implode('/',$segments);

          $retailers_profile_sql   = "SELECT * from redirect_store where old_url='".$old_url."'";
          $retailers_profile_rs    = mysqli_query($GLOBALS["___mysqli_ston"], $retailers_profile_sql) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false))); 
          $retailers_profile_row   = mysqli_fetch_array($retailers_profile_rs);
        
          if(mysqli_num_rows($retailers_profile_rs))// checking url exist or not.
          {
            $new_path = $retailers_profile_row['new_url'];
           
            header("HTTP/1.1 301 Moved Permanently");
            header("Location: ".$base_url.$new_path); 
            exit;
          }else{
                header("Location: ../404.php");  
               } 
          }else{
                $_REQUEST['userId'] = $retailer_row['user_id'];
                $_GET['userId']     = $retailer_row['user_id'];
            }


       //echo "SELECT * from retailer_product_category_junction WHERE retailer_id=".$retailer_row['user_id'];
       $retailer_cat       = mysqli_query($GLOBALS["___mysqli_ston"], "SELECT * from retailer_product_category_junction WHERE retailer_id=".$retailer_row['user_id']);
       $retailer_cat_rs    = mysqli_fetch_array($retailer_cat);
       $cat_id             = $retailer_cat_rs['category_id'];

       $_GET['catgid']           = $cat_id;     


               
                    

	}

//	public static function build_urls($url,$store_name)
//	{
//		global $seo_url; 
//		$url_parts = parse_url( $url );
//		parse_str( $url_parts['query'] , $query_ar );	
//		$url_segments  = array();
//		$url_segments[]  = "bretailerdetails";
//		$url_segments[]  = $store_name;
//                
//		if(isset($seo_url)&& $seo_url=="yes")
//                {
//		return implode('/',$url_segments);
//                }
//                else
//                {
//                return $url;
//                }
//	}
        
        
  public static function build_urls($url,$alias_url=0,$store_name='',$cat_name='')
	{
		
	global $seo_url;
	$url_parts  = parse_url( $url );
  parse_str( $url_parts['query'] , $query_ar );


	   $retailer_sql="select * from vendors_profile where user_id=".$query_ar['userId']."";
    $retailer_rs = mysqli_query($GLOBALS["___mysqli_ston"], $retailer_sql) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
    $retailer_row = mysqli_fetch_array($retailer_rs);

    $store_name= $retailer_row['alias']; 


		$url_segments    = array();
		$url_segments[]  = "vendors";
		$url_segments[]  = $store_name;
		$url_segments[]  = $cat_name;

    // first get the browse url & explode it
    
	// get data from both table
	
    // check if existing alias & entering url alias from retailers_profile  same return same url  
    
	// check if entering url match from existing url of same store then return url.
    
	// else no page found
                
                if((isset($seo_url)&& $seo_url=="yes") || ($alias_url==1))
                {
					return implode('/',$url_segments);
                }
                else{
                      return $url;
                    
                }
               
	}
        
}