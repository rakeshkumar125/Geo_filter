<?php 
error_reporting(E_ALL);
//Report all errors
//error_reporting(0);
global $seo_url;
if(!isset($_SESSION)){ session_start(); }

($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost", "root", "")) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
((bool)mysqli_query($GLOBALS["___mysqli_ston"], "USE mail")) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
mysqli_query($GLOBALS["___mysqli_ston"], 'SET CHARACTER SET utf8');

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
/*$seo = $settings_row["seo"] ; */
$site_base_path = $protocol.$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods'; 
/*$seo_url =$seo;*/
$base_url = $protocol.$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods/';
$server_path	=	$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods';

?>