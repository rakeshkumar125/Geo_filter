<?php 
//error_reporting(E_ALL);
//Report all errors
error_reporting(0);
/*define('currency','&pound');*/

if (defined('constant')) define('constant', 'value');

global $seo_url;
if(!isset($_SESSION))
{
	session_start();
}

($GLOBALS["___mysqli_ston"] = mysqli_connect("192.168.1.12", "php_user", "php_user")) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
((bool)mysqli_query($GLOBALS["___mysqli_ston"], "USE nurtured_foods")) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
mysqli_query($GLOBALS["___mysqli_ston"], 'SET CHARACTER SET utf8');
//date_default_timezone_set('Asia/Kuwait');

//date_default_timezone_set('America/Phoenix');
//echo date('Y-m-d H:i:s');exit;

$settings_query ="select * from settings";
$settings_rs = mysqli_query($GLOBALS["___mysqli_ston"], $settings_query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)).$project_query );
$settings_row = mysqli_fetch_array($settings_rs);
$application_title = $settings_row["application_title"] ; 
mysqli_query($GLOBALS["___mysqli_ston"], "SET GLOBAL log_bin_trust_function_creators = 1");

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$seo = $settings_row["seo"] ; 
$site_base_path = $protocol.$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods'; 

$seo_url =$seo;
$base_url = $protocol.$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods/';

$server_path	=	$_SERVER['HTTP_HOST'].'/shishir_dev/nurturedfoods';

  $db = new PDO('mysql:host=192.168.1.12;dbname=nurtured_foods', 'php_user', 'php_user',
    array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
?>