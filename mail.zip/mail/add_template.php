<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Dashboard with Off-canvas Sidebar</title>
		<meta name="generator" content="Bootply" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" rel="stylesheet">


		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
		<link href="css/editor.css" type="text/css" rel="stylesheet"/>
	</head>
	<body>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Project name</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Settings</a></li>
            <li><a href="#">Profile</a></li>
            <li><a href="#">Help</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
      </div>
</nav> 

<div class="container-fluid">
      
      <div class="row row-offcanvas row-offcanvas-left">
        
         <div class="col-sm-3 col-md-2 sidebar-offcanvas" id="sidebar" role="navigation">
           
           
<ul class="nav nav-sidebar">
              <li class="active"><a href="#">Overview</a></li>
              <li><a href="#">Reports</a></li>
              <li><a href="#">Analytics</a></li>
              <li><a href="#">Export</a></li>
            </ul>
            <ul class="nav nav-sidebar">
              <li><a href="">Nav item</a></li>
              <li><a href="">Nav item again</a></li>
              <li><a href="">One more nav</a></li>
              <li><a href="">Another nav item</a></li>
              <li><a href="">More navigation</a></li>
            </ul>
            <ul class="nav nav-sidebar">
              <li><a href="">Nav item again</a></li>
              <li><a href="">One more nav</a></li>
              <li><a href="">Another nav item</a></li>
            </ul> 
          
        </div><!--/span-->
        
        <div class="col-sm-9 col-md-10 main">
          <form id="add_template" name="add_template" action="services/process_template.php" class="form-horizontal" enctype="multipart/form-data" method="post">
		  
			  <div class="form-group">
				<label for="email">Template Name: </label>
				<input type="text" class="form-control" id="name" name="name">
			  </div>
			  <div class="form-group">
				<label for="pwd">Template Subject: </label>
				<input type="text" class="form-control" id="subject" name="subject">
			  </div>
			  
			   <div class="form-group">
				<label for="pwd">Template Data: </label>
				<textarea id="txtEditor" name="data"></textarea> 
			  </div>
			  
			   <div class="form-group">
				<label for="pwd">Template alias:(<span class="small">There is space not allowed</span>) </label>
				<input type="text" class="form-control" id="alias" name="alias">
			  </div>
			  
			<!--  <button type="submit" class="btn btn-default" id="add_template_submit" name="add_template_submit">Submit</button> -->
<div value="submit" data-loading-text="validating.. " class="btn btn-primary" id="add_template_submit" name="add_template_submit">register</div>
			  <!-- <div value="submit" class="btn btn-primary" id="add_band_submit" name="submit">save</div> -->
			</form>

          
      </div><!--/row-->
	</div>
</div><!--/.container-->

<footer>
  <!-- <p class="pull-right">©2014 Company</p> -->
</footer>
        
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/scripts.js"></script>
		<script src="js/editor.js"></script>
		<script src="js/jquery.server_validation.js"></script> 
		<script type="text/javascript">
		$(document).ready( function() {
			$("#txtEditor").Editor();
				
			
		});
		
		$(function(){
			$('#add_template_submit').click(function(){
				$("#txtEditor").val($("#txtEditor").Editor("getText"));
			});
			
			$('#add_template_submit').server_validation({
					form_id:'add_template',
					validtion_script:'services/process_template.php?only_valdate=yes',
			});	
		
		});
		 	
		</script>
	</body>
</html>