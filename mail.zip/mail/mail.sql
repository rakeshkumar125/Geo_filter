-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 25, 2015 at 05:39 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mail`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_mail_template`
--

CREATE TABLE IF NOT EXISTS `cms_mail_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(200) NOT NULL,
  `email_subject` varchar(500) NOT NULL,
  `template` text NOT NULL,
  `template_alias` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `cms_mail_template`
--

INSERT INTO `cms_mail_template` (`id`, `template_name`, `email_subject`, `template`, `template_alias`) VALUES
(25, 'color mail', 'this is the test subject', '<table class="table" align="center" height="148" cellpadding="2" cellspacing="2" width="770"><tbody><tr><td style="background-color: rgb(138, 43, 226);"><span style="font-weight: bold;"><span style="color: rgb(255, 255, 255);">&nbsp;Nutured foods</span></span><br></td></tr><tr><td>&nbsp; <br><p>Hello [username] [last_name],</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://localhost/router/[link]">Click Here</a> for activate your account or copy and paste [link] to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond. <br></p></td></tr><tr><td><br></td></tr><tr><td style="background-color: rgb(138, 43, 226);"><span style="color: rgb(255, 255, 255);"><span style="font-weight: bold;">&nbsp;Follow on facebook | | Twitter | Googlplus</span></span><br></td></tr></tbody></table>', 'color-template'),
(23, 'Nuturedfoods invoice test', 'Hi your order successfully done', '<p>Hello [username] [last_name],</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="[link]">Click Here</a> for activate your account or copy and paste [link] to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', 'invoice-mail');

-- --------------------------------------------------------

--
-- Table structure for table `mail_log`
--

CREATE TABLE IF NOT EXISTS `mail_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_to` varchar(200) NOT NULL,
  `mail_subject` varchar(200) NOT NULL,
  `mail_message` text NOT NULL,
  `date_time` datetime NOT NULL,
  `message_fail` enum('Y','N') NOT NULL DEFAULT 'N',
  `message_error` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `mail_log`
--

INSERT INTO `mail_log` (`id`, `mail_to`, `mail_subject`, `mail_message`, `date_time`, `message_fail`, `message_error`) VALUES
(15, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 12:52:03', 'Y', 'SMTP connect() failed.'),
(16, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 12:53:07', 'Y', 'SMTP connect() failed.'),
(17, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 12:58:13', 'Y', 'SMTP connect() failed.'),
(18, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 13:00:04', 'Y', 'SMTP connect() failed.'),
(19, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 13:03:45', 'Y', 'SMTP connect() failed.'),
(20, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 13:06:48', 'N', ''),
(21, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 13:08:00', 'N', ''),
(22, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 13:08:15', 'N', ''),
(23, 'rakesh@mailinator.com', 'Hi your order successfully done', '<p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond.&nbsp;</p>', '2015-09-25 17:14:48', 'N', ''),
(24, 'rakesh@mailinator.com', 'this is the test subject', '<table class="table" align="center" height="148" cellpadding="2" cellspacing="2" width="770"><tbody><tr><td style="background-color: rgb(138, 43, 226);"><span style="font-weight: bold;"><span style="color: rgb(255, 255, 255);">&nbsp;Nutured foods</span></span><br></td></tr><tr><td>&nbsp; <br><p>Hello Rakesh Kumar,</p><p>Welcome&nbsp;to&nbsp;Nurtured&nbsp;and&nbsp;thanks&nbsp;for&nbsp;signing&nbsp;up!</p><p>Please <a href="http://localhost/router/http://google.com">Click Here</a> for activate your account or copy and paste http://google.com to your browser.</p><p><strong>Libby<br>Owner&nbsp;&amp;&nbsp;Founder&nbsp;of&nbsp;Nurtured</strong>&nbsp;</p><p><strong>Note</strong>:&nbsp;This&nbsp;is&nbsp;an&nbsp;automated&nbsp;mail,&nbsp;please&nbsp;do&nbsp;not&nbsp;respond. <br></p></td></tr><tr><td><br></td></tr><tr><td style="background-color: rgb(138, 43, 226);"><span style="color: rgb(255, 255, 255);"><span style="font-weight: bold;">&nbsp;Follow on facebook | | Twitter | Googlplus</span></span><br></td></tr></tbody></table>', '2015-09-25 17:33:36', 'N', '');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `host_name` varchar(200) NOT NULL,
  `smtp_username` varchar(200) NOT NULL,
  `smtp_password` varchar(200) NOT NULL,
  `port` varchar(200) NOT NULL,
  `application_title` varchar(200) NOT NULL,
  `default_email` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `host_name`, `smtp_username`, `smtp_password`, `port`, `application_title`, `default_email`) VALUES
(4, 'mail.tsprojects.net', 'urthots@tsprojects.net', '9905345487', '25', 'Test Application', 'rakesh@technoscore.net');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
