<?php

class stats_detail
	{
	    
	    var $retailers_id =	0;
	    var $clicks = "";
		var $start_date = "";
		var $end_date = "";
		var $dataforRetailer = 0;
		var $uniquearr = array();
		
	
	// Constuctor 
	function stats_detail($params=array())
	{ 
		if (count($params) > 0)
		{
		 	$this->initialize($params);		
		}			 
	}
	
	
	// INITIALIZER
	function initialize($params = array())
	{
		if (count($params) > 0)
		{			
			
			// Settings the variable through configuration passed. "$key" used as config indexes.
			foreach ($params as $key => $val)
			{
				if (isset($this->$key))
				{
				 	$this->$key = $val;
				}
			}
		}
	}

	
	// for insert records of user.
	function statsRecord()
	{
		$retailers_id=$this->retailers_id;		
		$ip=$_SERVER['REMOTE_ADDR'];
		$query="INSERT INTO stats_row (ip_address,retailers_id) value('$ip','$retailers_id')";
		mysqli_query($GLOBALS["___mysqli_ston"], $query);
	}
	
	
	function pageLinkStats()
	{		
		$ip=$_SERVER['REMOTE_ADDR'];
		$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$query="INSERT INTO stats_link_row (link_from_ip,url_link) value('$ip','$url')";
		mysqli_query($GLOBALS["___mysqli_ston"], $query);
	}
	
	
	//Display graph
	function display_graph()
	{
		$query ="SELECT DATE_FORMAT(date_and_time, '%m/%d/%y') as date_and_time FROM stats_row where (date_and_time between '$this->start_date' and DATE_ADD('$this->end_date', INTERVAL 1 DAY)) and  retailers_id = '$this->dataforRetailer' group by DATE_FORMAT(date_and_time, '%m/%d/%y') order by DATE_FORMAT(date_and_time, '%m/%d/%y') asc";
		
		$query_rs	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$arr['graph'][] = array("Day","Visits","Unique Visitors");
		$TotalVisits = 0;
		$TotalUniqueVisitors = 0;
		while ($row = mysqli_fetch_array($query_rs)) {
			$rec_date = $row['date_and_time'];			
			$Visits = $this->totalVisits($rec_date);
			$TotalVisits += $Visits;
			 $TotalvisitDurat = $this->Totaltimevisit($rec_date);
			 $Totaltimevisit += $TotalvisitDurat;
			
			$UniqueVisitors = $this->uniqueVisiters($rec_date);			
			$arr['graph'][] = array($rec_date,(int)$Visits,$UniqueVisitors);			
		}
		
	
		$arr['totalvisits'] = "<b>Visits :</b> ".$TotalVisits;
		$arr['totaluniquevisitors'] = " <b>Unique Visitors : </b>".count($this->uniquearr);
		$arr['pagesView'] = " <b>PageViews : </b>".$this->pagesView();
		if($TotalVisits>0){	
			$arr['pagevisit'] = "<b>Page/visit :</b> ".(float)($this->pagesView()/$TotalVisits);
			$arr['avgduration'] = "<b>Page/Avg visit Duration :</b> ".(float)($Totaltimevisit/$TotalVisits);
		
		}
		
		
		if((int)$TotalVisits==0){$arr['showgraph']= false;}else{$arr['showgraph']= true;}
		exit;
		return json_encode($arr);
	}
	
	function totalVisits($rec_date ="")
	{		
		$query ="SELECT count(distinct ip_address) as ip_address FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y')='$rec_date' and retailers_id = '$this->dataforRetailer'";		
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$row = mysqli_fetch_row($result);
		return $row[0];
	}
		
	function uniqueVisiters($rec_date="")
	{ 		
		$query ="SELECT distinct ip_address FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y') = '$rec_date' and retailers_id = '$this->dataforRetailer' group by ip_address";
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$i=0;
		while($row = mysqli_fetch_assoc($result))			
		{	
			$query2 ="SELECT ip_address,count(*) as numa FROM stats_row where ip_address = '$row[ip_address]' and DATE_FORMAT(date_and_time, '%m/%d/%y') < '$rec_date' and retailers_id = '$this->dataforRetailer' group by ip_address";
			$result2 = mysqli_query($GLOBALS["___mysqli_ston"], $query2) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
			$num_rows = mysqli_num_rows($result2);
			if((int)$num_rows==0)
			{	
				$i++;
				$this->uniquearr[]= $i;
			}
		}		
		return $i;
	}
	
	function pagesView()
	{
		$query ="SELECT distinct DATE_FORMAT(insert_time, '%m/%d/%y'),count(*) from stats_link_row group by DATE_FORMAT(insert_time, '%m/%d/%y'),url_link";		
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$num_rows = mysqli_num_rows($result);
		return $num_rows;
	}
	
	
	function Totaltimevisit($rec_date ="")
	{	
		$totaltime =0.0;
		$query ="SELECT DATE_FORMAT(date_and_time, '%H:%i') as totalvisittime FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y')='$rec_date' and retailers_id = '$this->dataforRetailer'";		
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$rows = mysqli_fetch_array($result);
		echo "<pre>";
					print_r($rows);
			
		foreach($rows as $key => $row)
		{
			$insert_time = $row['totalvisittime'];
			if($key!=0)
			{
				$totaltime +=(float) $insert_time[$key] - $insert_time[$key-1];
			}
		}	
		
		return $totaltime;
	}
}



?> 