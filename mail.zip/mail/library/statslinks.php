<?php
include("library/stats_detail.php");
$stats_ob = new stats_detail();
$stats_ob->pageLinkStats();
?>