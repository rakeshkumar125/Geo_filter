<?php
class stats_detail
	{
	    var $retailers_id =	0;
	    var $product_id =	0;
	    var $clicks = "";
		var $start_date = "";
		var $end_date = "";
		var $dataforRetailer = 0;
		var $uniquearr = array();
		
	// Constuctor 
	function stats_detail($params=array())
	{ 
		if (count($params) > 0)
		{
		 	$this->initialize($params);		
		}			 
	}
	
	// INITIALIZER
	function initialize($params = array())
	{
		if (count($params) > 0)
		{			
			
			// Settings the variable through configuration passed. "$key" used as config indexes.
			foreach ($params as $key => $val)
			{
				if (isset($this->$key))
				{
				 	$this->$key = $val;
				}
			}
		}
	}

	
	// for insert records of user.
	function statsRecord()
	{
		$retailers_id=$this->retailers_id;		
		$ip=$_SERVER['REMOTE_ADDR'];
		$query="INSERT INTO stats_row (ip_address,retailers_id) value('$ip','$retailers_id')";
		mysqli_query($GLOBALS["___mysqli_ston"], $query);
	}
	
	function statsRecord_product()
	{	
		$product_id=$this->product_id;	 
		$cms_products_sql	=	"select user_id from cms_products where id=".$product_id."";
		$cms_products_rs	=	mysqli_query($GLOBALS["___mysqli_ston"], $cms_products_sql) or die();
		$cms_products_row	=	mysqli_fetch_array($cms_products_rs);
		$retailers_id	=	$cms_products_row['user_id'];
		$ip=$_SERVER['REMOTE_ADDR'];
		$query="INSERT INTO stats_row (retailers_id,product_id,page_type,ip_address) value('$retailers_id','$product_id','product_page','$ip')";
		mysqli_query($GLOBALS["___mysqli_ston"], $query);
	}
	
	
	function pageLinkStats()
	{		
		$ip=$_SERVER['REMOTE_ADDR'];
		$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$query="INSERT INTO stats_link_row (link_from_ip,url_link) value('$ip','$url')";
		mysqli_query($GLOBALS["___mysqli_ston"], $query);
	}
	
	function product_click_stats()
	{
		$product_stats = "";
		$query = "SELECT product_name,count(product_id) as click_count FROM stats_row left join cms_products on stats_row.product_id=cms_products.id where (date_and_time between '$this->start_date' and DATE_ADD('$this->end_date', INTERVAL 1 DAY)) and retailers_id = '$this->dataforRetailer' and page_type='product_page' group by stats_row.product_id ";
		$query_rs = mysqli_query($GLOBALS["___mysqli_ston"], $query);
		
		if(mysqli_num_rows($query_rs))
		{
			
			$product_stats = "	<h3 style='font-size:25px;'>visited product stats</h3>
								<table class='table'>
								<tr>
									<td><strong>product name</strong></td>
									<td><strong>no. of time visited</strong></td>
								</tr>
							";
		while($query_row = mysqli_fetch_array($query_rs))
		{
			$product_stats .= "<tr>
								<td>".$query_row['product_name']."</td>
								<td>".$query_row['click_count']."</td>	
								
							  </tr>";
		
		}

			$product_stats .= "</table>";
		}
		return $product_stats;
	}
	
	//Display graph
	function display_graph()
	{
		$query ="SELECT DATE_FORMAT(date_and_time, '%m/%d/%y') as date_and_time FROM stats_row where (date_and_time between '$this->start_date' and DATE_ADD('$this->end_date', INTERVAL 1 DAY)) and  retailers_id = '$this->dataforRetailer' group by DATE_FORMAT(date_and_time, '%m/%d/%y') order by DATE_FORMAT(date_and_time, '%m/%d/%y') asc";
		
		$query_rs	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$arr['graph'][] = array("Day","Visits","Unique Visitors");
		$TotalVisits = 0;
		$TotalUniqueVisitors = 0;
		$Totaltimevisit = 0;

		while ($row = mysqli_fetch_array($query_rs)) {
			$rec_date = $row['date_and_time'];			
			$Visits = $this->totalVisits($rec_date);
			$TotalVisits += $Visits;
			 $TotalvisitDurat = $this->Totaltimevisit($rec_date);
			 $Totaltimevisit += $TotalvisitDurat;
			
			$UniqueVisitors = $this->uniqueVisiters($rec_date);			
			$arr['graph'][] = array($rec_date,(int)$Visits,$UniqueVisitors);
			
		}
		
		//PRODUCT CLICK STATS
		$arr['product_click_stats'] = $this->product_click_stats();
	
		$arr['totalvisits'] = "<b>no. of time page visit :</b> ".$TotalVisits;
		$arr['totaluniquevisitors'] = " <b> unique visitors <small>calculate on ip address</small> : </b>".count($this->uniquearr);
		$arr['pagesView'] = " <b>no. of time page views : </b>".$this->pagesView();
		if($TotalVisits>0){	
			$arr['pagevisit'] = "<b>Page/visit :</b> ".(float)($this->pagesView()/$TotalVisits);
			$arr['avgduration'] = "<b>page/avg visit duration :</b> ".(float)($Totaltimevisit/$TotalVisits);
		
		}
		
		
		if((int)$TotalVisits==0){$arr['showgraph']= false;}else{$arr['showgraph']= true;}
		return json_encode($arr);
	}
	
	function totalVisits($rec_date ="")
	{		
		$query ="SELECT count(distinct ip_address) as ip_address FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y')='$rec_date' and retailers_id = '$this->dataforRetailer'";		
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$row = mysqli_fetch_row($result);
		return $row[0];
	}
		
	function uniqueVisiters($rec_date="")
	{ 		
		$query ="SELECT distinct ip_address FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y') = '$rec_date' and retailers_id = '$this->dataforRetailer' group by ip_address";
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$i=0;
		while($row = mysqli_fetch_assoc($result))			
		{	
			$query2 ="SELECT ip_address,count(*) as numa FROM stats_row where ip_address = '$row[ip_address]' and DATE_FORMAT(date_and_time, '%m/%d/%y') < '$rec_date' and retailers_id = '$this->dataforRetailer' group by ip_address";
			$result2 = mysqli_query($GLOBALS["___mysqli_ston"], $query2) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
			$num_rows = mysqli_num_rows($result2);
			if((int)$num_rows==0)
			{	
				$i++;
				$this->uniquearr[]= $i;
			}
		}		
		return $i;
	}
	
	function pagesView()
	{
		$query ="SELECT distinct DATE_FORMAT(insert_time, '%m/%d/%y'),count(*) from stats_link_row group by DATE_FORMAT(insert_time, '%m/%d/%y'),url_link";		
		$result	= mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		$num_rows = mysqli_num_rows($result);
		return $num_rows;
	}
	
	
	function Totaltimevisit($rec_date ="")
	{	
		/* $totaltime =0.0;
		$query ="SELECT DATE_FORMAT(date_and_time, '%H:%i') as totalvisittime FROM stats_row where DATE_FORMAT(date_and_time, '%m/%d/%y')='$rec_date' and retailers_id = '$this->dataforRetailer'";		
		$result	= mysql_query($query) or die(mysql_error());
		$rows = mysql_fetch_array($result);
		
		foreach($rows as $key => $row)
		{	
			$insert_time = $row["totalvisittime"];
			if($key!=0)
			{
				$totaltime +=(float) $insert_time[$key] - $insert_time[$key-1];
			}
		}	
		return $totaltime; */
		return 0;
	}
}



?> 