<?php
function num_format($number){

return number_format((float)round($number,2), 2, '.', '');

}
 
?>