<?php
/*
Programmer : Shishir Raven & vishnu sharma
*/
if(file_exists('library/plugins.php'))
{
include('library/plugins.php');
}
else
{
include('../library/plugins.php');
}
abstract Class cms_payments extends cms_plugin 
{
	var $paid_order = array();
    var $hook_file  = "";
	abstract public function processPayment();
    abstract public function validatePayment($return_transaction_array);


    function __construct($params=array()) 
	{
		parent::__construct($params);
	}

    public function afterPaymentHooks($paid_order)
    {
    	// Loading Hooks. 

    	// Including hooks file if it is set and exists
		$has_hooks = false;
		if($this->hooks_file != "")
		{
			$hook_file =  $this->hooks_file;
			if (file_exists($hook_file)) 
			{
				// Load the hooks file
				include($hook_file);
				$has_hooks = true;
			}
			else
			{
				echo "Specified Hooks file is Not found <br> " . $hook_file;
			}
		} // Including hooks file finished.

		if($has_hooks == true)
		{
			$values = after_payment::process_order($values);
		}

    }

    public function beforePayment($cart_data)
    {
    	$data				=	$cart_data;	
		$userID				=	$data->userID;
		$payment_status		=	'pending';
		$payment_amount		=	$data->total_amount;
		$purchase_date		=	date('Y-m-d h:i:s');

		//INSERT ORDER IN MASTER TABLE
		$order_master_sql	=	"insert into cms_order_master (user_id,total_amount,payment_status,purchase_date,create_date,modify_date) values(".$userID.",'".$payment_amount."','".$payment_status."','".$purchase_date."',NOW(),NOW())";
		mysqli_query($GLOBALS["___mysqli_ston"], $order_master_sql) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		
		$order_id	=	((is_null($___mysqli_res = mysqli_insert_id($GLOBALS["___mysqli_ston"]))) ? false : $___mysqli_res); 

		//INSERT PRODUCT PURCHASE INFO IN SUMMARY TABLE

		foreach( $cart_data->products as $product )
		{	 
			$product_id		=	$product->product_key;
			$product_name	=	$product->product_name;
			$product_price	=	$product->product_price; 
		
			//INSERT INTO PACKAGES ORDER TABLE
			$sub_packages_master_sql	=	"insert into cms_order_summary (order_id,user_id,product_id,product_name,product_price,created_on,modified_on) values(".$order_id.",".$userID.",".$product_id.",'".$product_name."','".$product_price."',NOW(),NOW())";
			$sub_packages_order_master_rs	=	mysqli_query($GLOBALS["___mysqli_ston"], $sub_packages_master_sql) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
		}
		return $order_id;	
    }
}

class products
{
	var $products = array();
	var $total_amount;
	var $userID;
	 function __construct()
	 {
	 	unset($_SESSION['payment_gateway_vars']);
	 		
	 	if(isset($_SESSION['shopping_cart']->order_id))
		{
			$orderID = $_SESSION['shopping_cart']->order_id;
			$userID = $_SESSION['shopping_cart']->userID;
			//IF ORDER ID IS ALREADY SET REMOVE THAT ORDER
		 	$delete_order	=	"delete from cms_order_master where id=".$orderID." and payment_status='pending' and user_id=".$userID."";
			if(mysqli_query($GLOBALS["___mysqli_ston"], $delete_order))
			{
				$delete_order_summary = "delete from cms_order_summary where order_id=".$orderID." and user_id=".$userID."";
				mysqli_query($GLOBALS["___mysqli_ston"], $delete_order_summary);
			}
		}
	 	
	 }

	public function add_products($product_object){
		if(get_class($product_object)=="product")
		{
			$this->total_amount	=	$this->total_amount + $product_object->product_price;
			$this->products[] = $product_object;
		}
		else
		{
			die("Products Class only Accepts Product Object");
		}
	}
	public function setUserID($userID)
	{
		$this->userID = $userID;
	}
}



class product
{
	 var $product_key =  "";
	 var $product_name = "";
	 var $product_desc = "";
	 var $product_price = "";

	 function __construct($p_key,$p_name,$p_desc,$p_price,$p_role,$p_credit,$p_type){
 		 $this->product_key =  $p_key;
		 $this->product_name = $p_name;
		 $this->product_desc = $p_desc;
	 	 $this->product_price = $p_price;
	 	 $this->product_role = $p_role;
	 	 $this->product_credit = $p_credit;
	 	 $this->product_type = $p_type;

	 }
}


?>