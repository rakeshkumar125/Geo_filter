<?php
		
	include("../connection.php");
	include('../library/mail_template.php');
	$config['array_to_replace'] = array('username'=>"Rakesh",
										'last_name'=>"Kumar",
										'link'=>"http://google.com");

	$config['send_to'] = "rakesh@mailinator.com"; //mail to user
	$config['template_name'] = "color-template";
	$mailtemplate = new mailtemplate($config);
	$mailtemplate->sendmail(); 

?>