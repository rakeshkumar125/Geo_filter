<?php

	include("../connection.php") ;
		 include("../library/validate.php");
$last_insert_update_id ="";		
$config = array();
$config['array_to_validate'] 		= $_POST;
$config['required']	= "name,subject,alias";
$config['email'] 	= "";
$config['numeric']  = "";
$config['url']		= "";
$config['alpha']	= "";
$config['alphanumeric']	= "";
$unique_checks	=	array();
$config['unique_from_table'] = $unique_checks;
$compare_checks	=	array();
$config['compare'] = $compare_checks;
$min_checks	=	array();
$config['min_character_limit'] = $min_checks;
$max_checks	=	array();
$config['max_character_limit'] = $max_checks;
if($_GET['only_valdate']=='yes')
{
	only_validate($config); // run if ajax call
}
else
{
	validate_and_insert($config); // run if normal call
}		
// this will respond to the ajax call
function only_validate($config){
	$my_validator = new validator($config);
	$error = $my_validator->process_validation();
	echo json_encode($error);
}
function validate_and_insert($config)
{
	if(isset($_REQUEST))
		{
		$my_validator = new validator($config);
		$error = $my_validator->process_validation();
		$message = "";
		if($error != false)
		{
			foreach($error as $error_message)
			{
				$message	.=	$error_message['error_field'].'-'.$error_message['error'].'<br>';
			}
			$message=array( 'title'=>'Add',
							'text'=>$message,
							'type'=>'error');
			$_SESSION['message'][]=$message;
			header("location:../".$_POST['page_name']);
			exit;
		}
   $value_ar = array();
   $value_ar[] = "'".((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $_REQUEST['id']) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : "")). "'";
   $value_ar[] = "'".((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $_REQUEST['name']) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : "")). "'";
   $value_ar[] = "'".((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $_REQUEST['subject']) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : "")). "'";
   $value_ar[] = "'".((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $_REQUEST['data']) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : "")). "'";
   $value_ar[] = "'".((isset($GLOBALS["___mysqli_ston"]) && is_object($GLOBALS["___mysqli_ston"])) ? mysqli_real_escape_string($GLOBALS["___mysqli_ston"], $_REQUEST['alias']) : ((trigger_error("[MySQLConverterToo] Fix the mysql_escape_string() call! This code does not work.", E_USER_ERROR)) ? "" : "")). "'";
$insert_columns_data = implode(',',$value_ar);
   $columns_ar = array();
  $columns_ar[] = 'id';
  $columns_ar[] = 'template_name';
  $columns_ar[] = 'email_subject';
  $columns_ar[] = 'template';
  $columns_ar[] = 'template_alias';
$insert_columns = implode(',',$columns_ar);
 $val = array();
 $val[] = 'id=VALUES(id)';
 $val[] = 'template_name=VALUES(template_name)';
 $val[] = 'email_subject=VALUES(email_subject)';
 $val[] = 'template=VALUES(template)';
 $val[] = 'template_alias=VALUES(template_alias)';
 $values = implode(',',$val);
$query = "INSERT INTO cms_mail_template ( ".$insert_columns." ) values ($insert_columns_data)
ON DUPLICATE KEY update 
$values
";


mysqli_query($GLOBALS["___mysqli_ston"], $query) or die(((is_object($GLOBALS["___mysqli_ston"])) ? mysqli_error($GLOBALS["___mysqli_ston"]) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false)));
	if($query)
	{
		echo "successful";
		$last_insert_update_id = ((is_null($___mysqli_res = mysqli_insert_id($GLOBALS["___mysqli_ston"]))) ? false : $___mysqli_res);
	}
	else
	{
		echo "failed";
	}
}
}
// Updating the Junction Table Starts here. 
if($last_insert_update_id==0)
{
	$last_insert_update_id = @$_REQUEST['id'];
}



?>